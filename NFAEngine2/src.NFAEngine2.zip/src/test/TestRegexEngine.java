/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import NFA.NFA;
import ParseTree.ParseTree;
import RegexEngine.ReEngine;

/**
 *
 * @author heckarim
 */
public class TestRegexEngine {

    public static void main(String[] args) {
        TestRegexEngine control = new TestRegexEngine();
        control.doTest();
        //control.doOutput();
        //control.doTest();
    }

    public void doTest() {
        //String rule = "/a*b?|c+(d|e)/smi";
        //String rule="/\\x3Ctitle\\x3ETroya\\s+\\x2D\\s+by\\s+Sma\\s+Soft\\x3C\\x2Ftitle\\x3E/smi";
        //String rule = "/abc(a|b|c){3,5}dabe/smi";
        //String rule = "/(\\(\\s*(\\x27[^\\x27]{1075,}|\\x22[^\\x22]{1075,})|\\(\\s*(\\x27[^\\x27]*\\x27|\\x22[^\\x22]+\\x22)\\s*,\\s*(\\x27[^\\x27]{1075,}|\\x22[^\\x22]{1075,})|\\(\\s*((\\x27[^\\x27]*\\x27|\\x22[^\\x22]+\\x22)\\s*,\\s*){2}(\\x27[^\\x27]{1075,}|\\x22[^\\x22]{1075,}))/si";
        String rule = "/InformixServerList=([^\\r\\n\\x3B]{,293}\\x3B)*[^\\r\\n\\x3B]{294}/i";

        ParseTree tree = new ParseTree(rule);
        System.out.println("pcre is: " + tree.rule.getPattern() + " -------- " + tree.rule.getModifier());
        tree.printTree();
        String s = "e";
        s = tree.patternOfPCRE(tree.root);
        System.out.println("patterm of pcre  " + s);
        tree.generateDotFile(null, null);

        NFA nfa = new NFA();
        nfa.buildNFA(tree);

        // nfa.updateID();
        System.out.println("Original NFA:");
        //nfa.print();
        nfa.generateDotFile("nfa_origin.dot", null);

        nfa.reduceRedundantState();
        nfa.generateDotFile("nfa_reduce.dot", null);
        //System.out.println("Modified NFA:");
        //Creat ReGexEngien
        ReEngine engine = new ReEngine();
        engine.buildEngine(nfa);
        engine.generateDotFile("ReEngine.dot", null);
        System.out.println("Original blockChar list : ");
        engine.printBlockChar();
        engine.reduceBlockChar();
        System.out.println("REduced blockChar list : ");
        engine.printBlockChar();
        
    }
}
